package com.epita;

/**
 * Your entry point.
 *
 * @author PSX
 * @since 1.0-SNAPSHOT
 */
public class Creeps {

    public static void main(final String... args) {
        // FIXME: place you entry point here.
        System.out.println("it works");
    }

}
