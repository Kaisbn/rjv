package com.epita.async;

import java.util.concurrent.Callable;
import java.util.function.Consumer;

/**
 * An async task. You can either use it directly or subclass it for commands implementation.
 *
 * @author PSX
 * @since 1.0-SNAPSHOT
 */
public class AsyncTask<RET_TYPE> implements Callable<RET_TYPE> {

    /**
     * Code to be passed and executed as a follow-up to the completion of the task.
     */
    public final Consumer<RET_TYPE> andThen;

    /**
     * Error handler.
     */
    public final Consumer<Throwable> onError;

    /**
     * Delay before execution of the task.
     */
    public final Long delay;

    /**
     * The task to execute.
     */
    public final Callable<RET_TYPE> command;

    /**
     * CTor.
     *
     * @param command
     * @param andThen
     * @param delay
     */
    public AsyncTask(final Callable<RET_TYPE> command, final Consumer<RET_TYPE> andThen, final Long delay) {
        this(command, andThen, err -> err.printStackTrace(System.err), delay);
    }

    /**
     * CTor.
     *
     * @param command
     * @param onError
     * @param andThen
     */
    public AsyncTask(final Callable<RET_TYPE> command, final Consumer<Throwable>
            onError, final Consumer<RET_TYPE> andThen) {
        this(command, andThen, onError, 0l);
    }

    /**
     * CTor.
     *
     * @param command
     * @param andThen
     */
    public AsyncTask(final Callable<RET_TYPE> command, final Consumer<RET_TYPE> andThen) {
        this(command, andThen, err -> err.printStackTrace(System.err), 0l);
    }

    /**
     * CTor.
     *
     * @param command
     * @param andThen
     * @param onError
     * @param delay
     */
    public AsyncTask(final Callable<RET_TYPE> command, final Consumer<RET_TYPE> andThen, final Consumer<Throwable>
            onError, final Long delay) {
        this.command = command;
        this.andThen = andThen;
        this.onError = onError;
        this.delay = delay;
    }

    @Override
    public RET_TYPE call() throws Exception {
        try {
            return command.call();
        } catch (Throwable err) {
            onError.accept(err);
        }
        return null;
    }
}
