package com.epita.async;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.*;
import java.util.stream.Collectors;

/**
 * Manager that can accept AsyncTaskManager instance and will start them. Upon completion, the follow up action provided
 * will be called.
 * <p>
 * An optional handler can be provided to handle exceptions.
 *
 * @author PSX
 * @since 1.0-SNAPSHOT
 */
public class AsyncTaskManager {

    /**
     * Singleton instance.
     */
    public static final AsyncTaskManager INSTANCE = new AsyncTaskManager();

    /**
     * Scheduler instance. Will scale on all available processors.
     */
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(Runtime.getRuntime()
            .availableProcessors());

    /**
     * Map of the stored futures/tasks.
     */
    final Map<ScheduledFuture<?>, AsyncTask> futures = new HashMap<>();

    /**
     * Allow submission of tasks.
     *
     * @param task
     *         The task to submit.
     * @param <RT>
     *         The expected return type.
     */
    public <RT> void submit(final AsyncTask<RT> task) {
        ScheduledFuture<RT> future = scheduler.schedule(task, task.delay, TimeUnit.MILLISECONDS);
        futures.put(future, task);
    }

    /**
     * Default private constructor.
     */
    private AsyncTaskManager() {
        scheduler.scheduleAtFixedRate(() -> checkFutures(), 10, 1, TimeUnit.MILLISECONDS);
    }

    /**
     * Internal loop, checking for terminated futures.
     */
    private void checkFutures() {
        try {
            final Set<ScheduledFuture> done = futures.entrySet().stream().filter(entry -> entry.getKey().isDone())
                    .map(it -> it.getKey()).collect(Collectors.toSet());
            for (ScheduledFuture it : done) {
                futures.get(it).andThen.accept(it.get());
                futures.remove(it);
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

}
