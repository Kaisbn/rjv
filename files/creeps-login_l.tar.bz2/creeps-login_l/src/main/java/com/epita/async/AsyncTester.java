package com.epita.async;

/**
 * You may want to add a meaningful comment here.
 *
 * @author PSX
 * @since 1.0-SNAPSHOT
 */
public class AsyncTester {

    public static void main(final String... args) {

        AsyncTaskManager.INSTANCE.submit(
                new AsyncTask<>(() -> "first",
                        (str) -> {
                            AsyncTaskManager.INSTANCE.submit(new AsyncTask<>(() -> {
                                Integer x = 0;
                                Integer res = 42 / x;
                                return str + " error";
                            }, str2 -> {
                            }, err -> {
                                System.err.println("oops: " + err.getMessage());
                            }, 3000l));
                        }, 2000l));
    }

}
