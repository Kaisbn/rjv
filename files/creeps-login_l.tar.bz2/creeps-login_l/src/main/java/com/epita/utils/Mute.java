package com.epita.utils;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * You may want to add a meaningful comment here.
 *
 * @author PSX
 * @since 1.0-SNAPSHOT
 */
public class Mute {

    private static final Logger LOGGER = Logger.getLogger("com.epita.utils.Mute");

    @FunctionalInterface
    interface CheckedRunnable {

        void run() throws Throwable;
    }

    public static void log(CheckedRunnable r) {
        try {
            r.run();
        } catch (Throwable log) {
            // Logs the exception.
            LOGGER.log(Level.SEVERE, log.getMessage());
        }
    }
}
